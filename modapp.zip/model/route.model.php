<?php

class ruta{
    public function obtenerRuta(){
        return "http://localhost:8888/GitHub/Services-Modapp/";
    }
}

?>